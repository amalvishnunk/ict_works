const mongoose=require('mongoose');
mongoose.connect("mongodb://localhost:27017/LibraryDB");
const Schema=mongoose.Schema;

var author_schema=new Schema({

    name: String,
    works:String,
    period:String
});

var authdata=mongoose.model('auth-data',author_schema);

module.exports=authdata;