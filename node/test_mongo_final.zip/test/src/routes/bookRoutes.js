const express =require('express');
const bookRouter=express.Router();
const Bookdata=require('../model/book_data');
const mongoose=require('mongoose');
var b;
function router(nav){



bookRouter.route('/')
.get(
    (req,res)=>{

        Bookdata.find().then(function(books){
          
            res.render('books',{nav,books})
        });

    }
)

bookRouter.route('/:id')
.get((req,res)=>{
    const id=req.params.id;

    Bookdata.findOne({_id:id}).then(function(book){res.render('book',{nav,book}) });
    
})

return bookRouter;

}
module.exports=router;











// var books=[{title:'book1',author:'author1',genre:'history'},
// {title:'book2',author:'author2',genre:'fiction'},
// {title:'book3',author:'author3',genre:'Fiction'}] ;


// var nav=[
//     {link:'books',title:'Books'},
//     {link:'authors',title:'Authors'},
//     {link:'about_us',title:'About Us'},
//     // {link:'contact_us',title:'Contact Us'}];