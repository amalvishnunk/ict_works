const express=require('express');
const Authdata=require('../model/author_data');
const admin1Router=express.Router();

function router(nav){
    admin1Router.route('/').get((req,res)=>{
        res.render('aut_form',{nav});
    });

    admin1Router.route('/add').get((req,res)=>{
        var item={
            name:req.param('author_name'),
            works:req.param('author_works'),
            period:req.param('author_period')  
        }

        var auth=new Authdata(item);
        auth.save();
        res.redirect('/');


    });



return admin1Router;
}
module.exports=router;