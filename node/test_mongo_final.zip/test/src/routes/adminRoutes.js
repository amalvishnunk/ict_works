const express=require('express');
const Bookdata=require('../model/book_data.js');
const adminRouter=express.Router();

function router(nav){
    adminRouter.route('/').get((req,res)=>{
        res.render('form',{nav});
    })

    adminRouter.route('/add').get((req,res)=>{
        var item={
            title:req.param('book_name'),
            author:req.param('aut_name'),
            genre:req.param('b_genre')
        }
        var book=new Bookdata(item);
        book.save();
        res.redirect('/books');
        // redirects after processing 
    })

    return adminRouter;
}
module.exports=router;