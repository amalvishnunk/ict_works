const express =require('express');
const authorRouter=express.Router();
const Authdata=require('../model/author_data');
function router(nav){

authorRouter.route('/')
    .get((req,res)=>{

        Authdata.find().then(function(auth){
            res.render('authors',{nav,auth})

        });
    });
authorRouter.route('/:id').get((req,res)=>{
  const id=req.params.id;
  Authdata.findOne({_id:id}).then(function(auth){
    //   console.log(auth);
    res.render('author',{nav,auth})
  })  ;

})




    return authorRouter;
}
module.exports=router;











// var nav=[
//     {link:'books',title:'Books'},
//     {link:'authors',title:'Authors'},
//     {link:'about_us',title:'About Us'},
//     {link:'contact_us',title:'Contact Us'}
// ];



// var books=[{title:'book1',author:'author1',genre:'history'},
// {title:'book2',author:'author2',genre:'fiction'},
// {title:'book3',author:'author3',genre:'Fiction'},
// ] ;
