const express=require('express')
const submitRouter=express.Router();

function router(nav){
    submitRouter.route('/').get((req,res)=>{
        res.render('form',{nav});
    })
    return submitRouter;
}
module.exports=router;