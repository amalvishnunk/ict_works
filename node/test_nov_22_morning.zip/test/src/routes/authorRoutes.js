const express =require('express');
const authorRouter=express.Router();
var nav=[
    {link:'books',title:'Books'},
    {link:'authors',title:'Authors'},
    {link:'about_us',title:'About Us'},
    {link:'contact_us',title:'Contact Us'}
];
var books=[{title:'book1',author:'author1',genre:'history'},
{title:'book2',author:'author2',genre:'fiction'},
{title:'book3',author:'author3',genre:'Fiction'}] ;

authorRouter.route('/')
    .get((req,res)=>{
        res.render('authors',{nav
        ,books})
    });
authorRouter.route('/:id')
    .get((req,res)=>{
        const id=req.params.id;
        res.render('author',{
            nav,book: books[id]
        })
    });

module.exports=authorRouter;