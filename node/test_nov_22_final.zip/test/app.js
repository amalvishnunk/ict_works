const express =require('express');
const chalk=require('chalk');
const path=require('path');
var nav=[
    {link:'books',title:'Books'},
    {link:'authors',title:'Authors'},
    {link:'about_us',title:'About Us'},
    {link:'contact_us',title:'Contact Us'},
    {link:'submit_book',title:'Submit a book'}
];    

const bookRouter=require('./src/routes/bookRoutes')(nav);
const authorRouter=require('./src/routes/authorRoutes')(nav);
const aboutRouter=require('./src/routes/aboutRoutes')(nav);
const contactRouter=require('./src/routes/contactRouter')(nav);
const submitRouter=require('./src/routes/submitRouter')(nav);
var app=new express();

app.use(express.static(path.join(__dirname,'/public')));
app.use('/books',bookRouter);
app.use('/authors',authorRouter);
app.use('/about_us',aboutRouter);
app.use('/contact_us',contactRouter);
app.use('/submit_book',submitRouter);

app.set('views','./src/views');
app.set('view engine','ejs');


app.get('/',function(req,res){
    //sending text
    // res.send('homepage'); 
    // res.sendFile(__dirname+'/views/index.html');
    // res.sendFile(path.join(__dirname,'views_old/index.html'));
    res.render('index',
    {
        title:'Library',name:'Ict',nav
    });
});


app.listen(3000,function(){
    console.log('listening to port '+chalk.green('3000'));
})