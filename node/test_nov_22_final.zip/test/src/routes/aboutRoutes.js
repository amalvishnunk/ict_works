const express=require('express')
const aboutRouter=express.Router();
var team=[{title:'CEO',name:'Rajesh'},
    {title:'CFO',name:'Ravi'},
    {title:'Marketing',name:'Suresh'}
];
function router(nav){
    aboutRouter.route('/').get((req,res)=>{
        res.render('about',{nav,team});
    })

return aboutRouter

}
module.exports=router;
