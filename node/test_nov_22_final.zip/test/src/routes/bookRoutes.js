const express =require('express');
const bookRouter=express.Router();


function router(nav){

var books=[{title:'book1',author:'author1',genre:'history'},
{title:'book2',author:'author2',genre:'fiction'},
{title:'book3',author:'author3',genre:'Fiction'}] ;


bookRouter.route('/')
.get(
    (req,res)=>{
        res.render('books',
        {nav,books
          }) 
    }
)

bookRouter.route('/:id')
.get((req,res)=>{
    
    const id=req.params.id;
    res.render('book',
    {nav,
    book: books[id]
    })
})

return bookRouter;

}
module.exports=router;














// var nav=[
//     {link:'books',title:'Books'},
//     {link:'authors',title:'Authors'},
//     {link:'about_us',title:'About Us'},
//     // {link:'contact_us',title:'Contact Us'}];