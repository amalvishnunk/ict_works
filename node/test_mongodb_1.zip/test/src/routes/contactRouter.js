const express=require('express')
const contactRouter=express.Router();
var address=[{loc:'Calicut',adr:'address 1'},
{loc:'Eranakulam',adr:'address 2'},
{loc:'Trivandrum',adr:'address 3'},
];
function asdfgg(nav){
    contactRouter.route('/').get((req,res)=>{
        res.render('contact',{nav,address});
    })
    return contactRouter;
}
module.exports=asdfgg;