const mongoose=require('mongoose');
mongoose.connect("mongodb://localhost:27017/LibraryDB");
const Schema=mongoose.Schema;

var book_schema=new Schema({
    title:String,
    author:String,
    genre:String
});

var bookdata=mongoose.model('book-data',book_schema);
// mongodb renames book-data to book-datas
module.exports=bookdata;
