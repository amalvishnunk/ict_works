const express =require('express');
const chalk=require('chalk');
const path=require('path');
var app=new express();
app.use(express.static(path.join(__dirname,'/public')));
app.set('views','./src/views');
app.set('view engine','ejs');


app.get('/',function(req,res){
    //sending text
    // res.send('homepage'); 
    // res.sendFile(__dirname+'/views/index.html');
    // res.sendFile(path.join(__dirname,'views_old/index.html'));
    res.render('index',{title:'Library',name:'Ict',list:['book1','book2','book3','book4','book5']});
});

app.listen(3000,function(){
    console.log('listening to port '+chalk.green('3000'));
})