const express =require('express');
const chalk=require('chalk');
const path=require('path');
var app=new express();
const bookRouter=express.Router();
const authorRouter=express.Router();
app.use(express.static(path.join(__dirname,'/public')));
app.use('/books',bookRouter);
app.use('/authors',authorRouter);

bookRouter.route('/')
.get(
    (req,res)=>{
        res.render('books',{nav:[{link:'books',title:'Books'}],books:[{title:'book1',author:'author1',genre:'history'},{title:'book2',author:'author2',genre:'fiction'},{title:'book3',author:'author3',genre:'Fiction'}]}) 
    }
)

bookRouter.route('/single')
.get((req,res)=>{res.send("hello single book")});

authorRouter.route('/')
.get((req,res)=>{res.send("hello authors")});
authorRouter.route('/single')
.get((req,res)=>{res.send("hello single author")});

app.set('views','./src/views');
app.set('view engine','ejs');


app.get('/',function(req,res){
    //sending text
    // res.send('homepage'); 
    // res.sendFile(__dirname+'/views/index.html');
    // res.sendFile(path.join(__dirname,'views_old/index.html'));
    res.render('index',{title:'Library',name:'Ict',nav:[{link:'books',title:'Books'},{link:'authors',title:'Authors'},{link:'about_us',title:'About Us'},{link:'contact_us',title:'Contact Us'}]});
});


app.listen(3000,function(){
    console.log('listening to port '+chalk.green('3000'));
})