const express=require('express');
const path=require('path');
var dept=[{title:'CSE',des:'A computer engineer, also called a software engineer, is responsible for developing, testing and evaluating the software that make our computers work. They may help in the development of new computer games and business applications, or even in the design of entirely new operating systems. '},
            {title:'EEE',des:'Electrical engineers design, develop, test, and supervise the manufacturing of electrical equipment, such as electric motors, radar and navigation systems, communications systems, or power generation equipment. Electrical engineers also design the electrical systems of automobiles and aircraft.'},
            {title:'ECE',des:'Electronics and Communications Engineering is the utilisation of science and math applied to practical problems in the field of electronics and communications. Electronics and communications engineers engage in research, design, development and testing of the electronic equipment used in various systems.'},
            {title:'CIVIL',des:'Civil engineers create, improve and protect the environment in which we live. They plan, design and oversee construction and maintenance of building structures and infrastructure, such as roads, railways, airports, bridges, harbours, dams, irrigation projects, power plants, and water and sewerage systems.'}
];


const cseRouter=require('./src/routes/cseRouter')(dept);
const eeeRouter=require('./src/routes/eeeRouter')(dept);
const eceRouter=require('./src/routes/eceRouter')(dept);
const civilRouter=require('./src/routes/civilRouter')(dept);
const csestaffRouter=require('./src/routes/csestaffRouter')(dept);
const eeestaffRouter=require('./src/routes/eeestaffRouter')(dept);
const ecestaffRouter=require('./src/routes/ecestaffRouter')(dept);
const civilstaffRouter=require('./src/routes/civilstaffRouter')(dept);




var app=new express();
app.use(express.static(path.join(__dirname,'/public')));
app.set('views','./src/views');
app.set('view engine','ejs');

app.use('/cse_dept',cseRouter);
app.use('/eee_dept',eeeRouter);
app.use('/ece_dept',eceRouter);
app.use('/civil_dept',civilRouter);
app.use('/cse_staff',csestaffRouter);
app.use('/eee_staff',eeestaffRouter);
app.use('/ece_staff',ecestaffRouter);
app.use('/civil_staff',civilstaffRouter);



app.get('/',function(req,res){
    res.render('index');
});

app.listen(3000,function(){
console.log("listening to port 3000");
});
