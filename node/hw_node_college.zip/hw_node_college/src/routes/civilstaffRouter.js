const express=require('express');
const civilstaffRouter=express.Router();
const id=3;

const staff=[{name:'K. Anoop',title:'HOD',no:'9876543210',dept:'CIVIL',path:'civil_staff'},
{name:'Anagha',title:'Faculty',no:'8766785543',dept:'CIVIL',path:'civil_staff'},{name:'Raghu',title:'Faculty',no:'99886754322',dept:'CIVIL',path:'civil_staff'},
{name:'Deepthi',title:'Facuty',no:'9889456743',dept:'CIVIL',path:'civil_staff'}];


function router(dept) {

    
    civilstaffRouter.route('/').get((req,res)=>{
        res.render('staffs',{dept,id,staff});
        // console.log(id);
    });

    civilstaffRouter.route('/:k').get((req,res)=>{
        const k=req.params.k;
        console.log(k);
        res.render('staff',{dept,id,s:staff[k]});
        
    });
    
    
    return civilstaffRouter;
    
    }
    module.exports=router;
