const express=require('express');
const eeestaffRouter=express.Router();
const id=1;

const staff=[{name:'Shibu P ',title:'HOD',no:'9876543210',dept:'EEE',path:'eee_staff'},
{name:'Sanoop',title:'Faculty',no:'8766785543',dept:'EEE',path:'eee_staff'},{name:'Vijeesh',title:'Faculty',no:'99886754322',dept:'EEE',path:'eee_staff'},
{name:'Ajith',title:'Facuty',no:'9889456743',dept:'EEE',path:'eee_staff'}];


function router(dept) {

    
    eeestaffRouter.route('/').get((req,res)=>{
        res.render('staffs',{dept,id,staff});
        // console.log(id);
    });

    eeestaffRouter.route('/:k').get((req,res)=>{
        const k=req.params.k;
        console.log(k);
        res.render('staff',{dept,id,s:staff[k]});
        
    });
    
    
    return eeestaffRouter;
    
    }
    module.exports=router;
