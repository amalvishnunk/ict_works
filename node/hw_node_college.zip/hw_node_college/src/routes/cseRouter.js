const express=require('express');
const cseRouter=express.Router();
const id=0;

function router(dept) {

    
cseRouter.route('/').get((req,res)=>{
    res.render('departments',{dept,id});
})


return cseRouter;

}
module.exports=router;