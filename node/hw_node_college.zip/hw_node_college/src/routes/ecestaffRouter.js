const express=require('express');
const ecestaffRouter=express.Router();
const id=2;

const staff=[{name:'P.N Joshi',title:'HOD',no:'9876543210',dept:'ECE',path:'ece_staff'},
{name:'Anjali',title:'Faculty',no:'8766785543',dept:'ECE',path:'ece_staff'},{name:'Raju',title:'Faculty',no:'99886754322',dept:'ECE',path:'ece_staff'},
{name:'David',title:'Facuty',no:'9889456743',dept:'ECE',path:'ece_staff'}];


function router(dept) {

    
    ecestaffRouter.route('/').get((req,res)=>{
        res.render('staffs',{dept,id,staff});
        // console.log(id);
    });

    ecestaffRouter.route('/:k').get((req,res)=>{
        const k=req.params.k;
        console.log(k);
        res.render('staff',{dept,id,s:staff[k]});
        
    });
    
    
    return ecestaffRouter;
    
    }
    module.exports=router;
