const express=require('express');
const civilRouter=express.Router();
const id=3;
function router(dept) {

    
civilRouter.route('/').get((req,res)=>{
    res.render('departments',{dept,id});
})


return civilRouter;

}
module.exports=router;