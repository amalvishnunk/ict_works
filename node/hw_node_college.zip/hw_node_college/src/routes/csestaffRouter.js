const express=require('express');
const csestaffRouter=express.Router();
const id=0;

const staff=[{name:'B. Ravikumar',title:'HOD',no:'9876543210',dept:'CSE',path:'cse_staff'},
{name:'Sandhya',title:'Faculty',no:'8766785543',dept:'CSE',path:'cse_staff'},{name:'Vinu P',title:'Faculty',no:'99886754322',dept:'CSE',path:'cse_staff'},
{name:'Devan',title:'Facuty',no:'9889456743',dept:'CSE',path:'cse_staff'}];


function router(dept) {

    
    csestaffRouter.route('/').get((req,res)=>{
        res.render('staffs',{dept,id,staff});
        // console.log(id);
    });

    csestaffRouter.route('/:k').get((req,res)=>{
        const k=req.params.k;
        console.log(k);
        res.render('staff',{dept,id,s:staff[k]});
        
    });
    
    
    return csestaffRouter;
    
    }
    module.exports=router;
