const express=require('express');
const eeeRouter=express.Router();
const id=1;
function router(dept) {

    
eeeRouter.route('/').get((req,res)=>{
    res.render('departments',{dept,id});
})


return eeeRouter;

}
module.exports=router;