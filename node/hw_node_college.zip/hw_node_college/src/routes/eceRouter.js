const express=require('express');
const eceRouter=express.Router();
const id=2;
function router(dept) {

    
eceRouter.route('/').get((req,res)=>{
    res.render('departments',{dept,id});
})


return eceRouter;

}
module.exports=router;