import { Component, OnInit } from '@angular/core';
import{Iproduct} from './product.model'
import{ProductService} from '../../product.service'

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  providers:[ProductService],
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  
  showImage:boolean=false
  pageTitle:string="Product List"
  products:Iproduct[];
  
  imageToggle():void{
    this.showImage=!this.showImage;
  }

  constructor(private productServiceobject:ProductService) { }

  ngOnInit():void{
    this.productServiceobject.getproducts()
    .subscribe((data)=>{
      this.products=JSON.parse(JSON.stringify(data));
    })
  }

 

}
