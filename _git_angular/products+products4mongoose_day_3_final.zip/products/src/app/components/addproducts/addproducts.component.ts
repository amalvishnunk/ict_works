import { Component, OnInit } from '@angular/core';
import{Iproduct} from '../product-list/product.model'
import { ProductService } from '../../product.service';


@Component({
  selector: 'app-addproducts',
  templateUrl: './addproducts.component.html',
  styleUrls: ['./addproducts.component.css']
})
export class AddproductsComponent implements OnInit {
  pageTitle:string="Add Products"

  products=new Iproduct(null,null,null,null,null,null,null,null);

  constructor(private p:ProductService) { }

  Addproduct(){
    console.log(this.products);
    this.p.newproduct(this.products);
    // alert("products added")
  }

  ngOnInit() {
  }

}
