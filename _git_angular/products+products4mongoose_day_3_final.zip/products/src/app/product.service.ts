import { Injectable } from '@angular/core';
import {Iproduct} from './components/product-list/product.model'
import {HttpClient,HttpResponse} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  getproducts(){
    return(this.http.get("http://localhost:3000/products")) ;
  }

  newproduct(item:Iproduct){
    return this.http.post("http://localhost:3000/insert",{product:item})
    .subscribe((data)=>{
      console.log("hi");
    })
  }

  constructor(private http:HttpClient) { }
}
