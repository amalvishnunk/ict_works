import { NgModule } from '@angular/core';

import{Routes,RouterModule} from '@angular/router';
import{ProductListComponent}from '../components/product-list/product-list.component';
import{AddproductsComponent}from '../components/addproducts/addproducts.component';

const routes:Routes=[{path:'',component:ProductListComponent},
                      {path:'add',component:AddproductsComponent}]

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],exports:[RouterModule],
  declarations: []
})
export class AppRoutingModule { }
