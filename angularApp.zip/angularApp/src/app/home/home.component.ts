import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  title:string="My Homepage"
  name:string="Amal"
  products:any[]=[{
    "productid":1,
    "productname":"product 1",
    "productcode":"GDN-011"

  },{
    "productid":2,
    "productname":"product 2",
    "productcode":"GDN-012"
  },{
    "productid":3,
    "productname":"product 3",
    "productcode":"GDN-013"
  }];

  constructor() { }

  ngOnInit() {
  }

}
